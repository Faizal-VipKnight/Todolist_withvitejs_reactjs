function Form({ addTask, newTask }) {
    return (
      <div className="form-container">
        <header>
          <h2> To Do List </h2>
          <h2> Hal Yang Harus Kulakukan</h2>
         
        </header>
        <form className="input-box" onSubmit={addTask}>
          <input type="text" ref={newTask} placeholder="Add Your Task" />
          <button type="submit">Add Task</button>
        </form>
      </div>
    );
  }
  
  export default Form;
  