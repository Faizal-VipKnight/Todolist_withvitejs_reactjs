import TodoButton from './TodoButton';

function Todolist({ tasks, setTasks }) {
  // Fungsi untuk menandai tugas sebagai selesai
  const toggleComplete = (id) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  // Fungsi untuk menghapus tugas
  const removeTask = (id) => {
    setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id));
  };

  // Fungsi untuk memindahkan tugas
  const moveTask = (id, direction) => {
    const index = tasks.findIndex((task) => task.id === id);
    if (direction === 'up' && index > 0) {
      const updatedTasks = [...tasks];
      [updatedTasks[index - 1], updatedTasks[index]] = [
        updatedTasks[index],
        updatedTasks[index - 1],
      ];
      setTasks(updatedTasks);
    } else if (direction === 'down' && index < tasks.length - 1) {
      const updatedTasks = [...tasks];
      [updatedTasks[index + 1], updatedTasks[index]] = [
        updatedTasks[index],
        updatedTasks[index + 1],
      ];
      setTasks(updatedTasks);
    }
  };

  return (
    <div className="todolist-container">
      <ul>
        {tasks.map((task) => (
          <li key={task.id} className={task.completed ? 'completed' : ''}>
            <div className="task">{task.task}</div>
            <TodoButton
              id={task.id}
              moveTask={moveTask}
              removeTask={removeTask}
              toggleComplete={toggleComplete}
            />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Todolist;
