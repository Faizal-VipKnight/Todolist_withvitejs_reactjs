function TodoButton({ id, moveTask, removeTask, toggleComplete }) {
  return (
    <div className="todo-buttons">
      <button onClick={() => toggleComplete(id)}>✅</button>
      <button onClick={() => moveTask(id, 'up')}>⬆</button>
      <button onClick={() => moveTask(id, 'down')}>⬇</button>
      <button onClick={() => removeTask(id)}>🗑️</button>
    </div>
  );
}

export default TodoButton;
