import { useState, useRef } from 'react';
import Form from './components/Form';
import Todolist from './components/Todolist';
import './App.css';

function App() {
  const newTask = useRef('');
  const [tasks, setTasks] = useState([]);

  const addTask = (event) => {
    event.preventDefault();
    const taskText = newTask.current.value.trim();
    if (!taskText) {
      alert('Silakan masukan hal yang akan kamu kerjakan');
      return;
    }
    const newTaskItem = {
      id: Date.now(),
      task: taskText,
      completed: false,
    };
    setTasks((prevTasks) => [...prevTasks, newTaskItem]);
    newTask.current.value = '';
  };

  return (
    <div className="App">
      <Form addTask={addTask} newTask={newTask} />
      <Todolist tasks={tasks} setTasks={setTasks} />
    </div>
  );
}

export default App;
